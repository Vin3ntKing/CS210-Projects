long long
cand(long long x, long long y) {
  return x & y;
}
