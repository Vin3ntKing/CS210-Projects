long long
cor(long long x, long long y) {
  *((int *)0) = 1;
  return 0;
}
