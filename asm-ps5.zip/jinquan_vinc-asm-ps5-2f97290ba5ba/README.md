# Assembly: Writing a real program

** You may - and are encouraged to - complete this assignment in teams of two **

Building on our knowledge of how functions and IO work, we can now write a
more complex program in Assembly.

The program will require you to put together several of the assembly
aspects that we have been covering.  To be successful, you will need
to use gdb to explore the input data and carefully trace what your
program is doing.  You will also need to apply your knowledge of UNIX.
Finally, this is a relatively complicated program to write in assembly, so you should
heavily use git to manage your code development (We will examine your git histories 
when grading). 

**REMEMBER: Only keep source files in your respository:**
- **Do Not:** put binaries, output files, object files, etc. in your repo. 
- **Do:** put assembly source files, your Makefile, shell scripts, notes, etc in your repo

## Overview

The following is a quick overview of steps you will need to complete:
1. Convert your three fragments from the prior assignment into functions
2. Write a main routine that will iterate over and process the simple data processing language,
   invoking your three routines as needed.
3. After processing the last operation specified, your program will need to write the following binary values as output
   to starndard out: the final value of `rax`, the value at `SUM_POSITIVE`, the value at `SUM_NEGATIVE` and the
   entire range of memory between `CALC_DATA_BEGIN` and CALC_DATA_END`
4. Add more advanced commands to your program:
   - you are required to implement at least 'U', 'a', and 'l'
   - the rest are bonus
   - if you want add more bonus features let me know

## The Calc Program

Our goal is to construct a program that we will call `calc`.  The
program should be broken down into several assembly language routines.  Each
routine should be written in its own assembly (.S) file.  We will use
the assembler to translate each assembly file into its own relocatable object
file (.o).  Using the linker (ld), we will "link" together the
object files into a single executable file.  Since we will be linking in the data,
you should create a **new executable** for each data file that you want to process.

The name of each executable should be "calc_<data name>" where <data name> is the data the binary will contain and process.  Eg. To process the "simpleone" you would create a new "calc_simpleone" binary by linking the appropriate files together.  An example is shown below. 

### Linking and organization

The linker creates the executable by composing the object files
together.  This specifically involves assigning 
opcodes to a location in memory (an address), and an address for 
global data.  The
linker ensures that if a particular module (.o) references addresses in another
module, they are linked together properly.  For example, you will
be writing a main routine that will use the 'call' instruction to
invoke your other routines such as 'call sum'.  The linker will ensure
that the main routine and the sum routine are at specific locations
in memory and that, in the final executable, the opcode byte values
generated for 'call sum' correctly specify the address of where sum
will be located in memory.

Do not include or put all of your code in one assembly file.

The data for your program will be specified in a `.S` file that will need to be assembled and linked into your program.
The `data` directory contains several example data files along with the output
produced by our reference implementation (reference_* files).  To use a particular data file, you will need
to link the rest of your code to an object file created from the corresponding data .S file.
Note: when you are testing you can simply define the CALC_DATA_BEGIN and CALC_DATA_END in any file
you'd like, and place your test input in the area of memory between them (examine one of the provided data .S files to see  what you would do -- 'simpleone_cmds.S' is a nice simple example).

eg. To build and test your code with the data/simpleone_cmd.S you would need to
assemble this file and then link the resulting simpleone_cmd.o with the rest of you object files
to create your binary:
```
$ make calc_simpleone
as -g and.S -o and.o
as -g or.S -o or.o
as -g sum.S -o sum.o
as -g upper.S -o upper.o
as -g arraysum.S -o arraysum.o
as -g listsum.S -o listsum.o
as -g array.S -o array.o
as -g list.S -o list.o
as -g atoq.S -o atoq.o
as -g calc.S -o calc.o
as -g data/simpleone_cmds.S -o data/simpleone_cmds.o
ld -g and.o or.o sum.o upper.o arraysum.o listsum.o array.o list.o atoq.o calc.o data/simpleone_cmds.o -o calc_simpleone
$ 
```

The above is from the reference implementation that supports all the commands.
You will want to start with just supporting the `and`, `or` and `sum` functions.
 In the data directory, `basic_cmds.S` is a simple example that only uses these.
At the start, your binary might only be built out of a 'calc.S' 'and.S', 'or.S', 'sum.S' and a data object file
if you don't include some data directly  in your 'calc.S'. 
From there you can incrementally add more functions and files.

You will need to construct all the necessary files including a Makefile

### The Data Processing

The input to your program is an area of memory that contains data.   The handout includes assembly code for example data.   Your program  will be tested with some of these.   You are encouraged to explore these
files and write your own simpler data files so that you can develop and test your code properly.

Each data file is composed of an array of "commands" and optionally some other memory values.
The following describes the commands:
```
	# Input to the "Data Processor" is an area of
	# memory that contains an array of "commands" along with potentially extra data
    # as needed.
    #
	# The start of this memory will be identified by the symbol CALC_DATA_START
	# and the end of this memory will be identified by the symbol CALC_DATA_END
	# See the data directory for example data files.
	#
	#  The first 8 bytes are the command type. Following the command  are one or more 8-byte values 
	#  that form the arguments for that command type.  The format and meaning of the arguments depends on
	#  the command type.  ASCII values are used to specify the command type.  In
	#  the following description, values in single quotes refer to the associated
	#  ascii value.
	#
	#  There are two main categories of command types: simple and complex
	#
	#
	# SIMPLE COMMANDS
	#
	#  For simple commands, the first byte of the 8-byte command will be one of:
	#    '&', '|', 'S', 'a', 'l', 'U', 'I'
	#  In these cases the remaining 7 bytes are padding and should be ignored.
	#  The next 8 bytes are the single argument to the simple command.  'a' command takes
	#  an additionaly 8 byte command as described below.
	#  The following describes what your program should do to process each of the simple
	#  commands:
	#
	#    '&'  :  AND: Takes one argument: update rax with the bitwise and of the
	#         :  current value of rax and the argument
	#         :  value eg.  rax = rax bitwise and with the 8-byte argument value
	#    '|'  :  OR: Takes one argument: same as above but apply bitwise or.
	#    'S'  :  SUM: Takes one argument: your sum routine should both 
	#         :       update rax by summing the value into rax, and update either
	#         :       the global "positive" or "negative" sum as needed.
	#    'a'  :  ARRAYSUM: Takes two 8-byte arguments:  First is a length, and
	#         :            the second is an 8-byte address to an array of 8-byte values.
	#         :            You should apply the sum operator to each value in the array.
	#    'l'  :  LISTSUM:  Takes one argument: The argument is an 8-byte address of
	#         :            a list of values.  You should iterate over the list and
	#         :            apply the sum operator to the values.  Each list element is 
	#         :            16 bytes.  The first 8 bytes is the value in the element.
	#         :            The next 8 bytes is an address that points to the next
	#         :            element in the list.  You should treat a 0 address to
	#         :            indicate the end of the list.
	#    'U'  :  UPPER: The second argument should be treated as a pointer to
	#         :         an ascii string (a sequence of non-zero bytes terminated 
	#         :         by a zero valued byte) eg 'a''b''c'0x0.  This command 
	#         :         should process the string converting lowercase letters
	#         :         ('a' - 'z') to their corresponding uppercase letter
	#         :         'A' - 'Z'.  The routine should also add the length of
	#         :         the string to rax. Note if the first byte of the string
	#         :         is zero then the string length is 0.  The length of
	#         :         'a'0x0 would be 1 and so on.
	#    'I'  : ATOQ:  The second argument should be treated as a pointer to an ascii
	#         :        string.  This string should be converted to a signed 8-byte
	#         :        value.  The converted value should be summed in rax and,
	#         :        like in the sum command, the SUM_POSITIVE and SUM_NEGATIVE should be updated correctly
	#
	# 
	# When you encounter a 0 byte as the command type you should stop processing commands.

	# COMPLEX COMMANDS
	#
	#
	#
	# 'A' :  ARRAY:  indicates that the next byte of the command type value will one of the
	#                following simple command characters '&','|','S' or 'U'
	#     eg.  'A''&' or 'A''|' or 'A''S' or 'A''U'.  The remaining 6 bytes of the command type
	#     value should be skipped.  The array command takes two 8-byte arguments that follow the type
	#     value.  The first is a Length value and the next is the address of an Array of values.
	#     Your code needs to run the specified simple command on each 8-byte value in the Array.
	#     The length specifies the number of items in the Array
	# 'L' : LIST:  Like Array, the next byte of the command type value will be one of the
	#              following simple command characters '&','|','S' or 'U'
	#     eg.  'L''&' or 'L''|' or 'L''S' or 'L''U'.  The remaining 6 bytes of the command type
	#     value should be skipped.  List command takes one 8-byte argument that follows the type value.
	#     The argument should be treated as a pointer to a "list" of arguments (if zero then the list is empty).
	#     Assuming a non-empty list your code should process
	#     each element of the list by applying the specified operator to the value in each list element.
	#     The structure of a list element is as follows:
	#       <8 byte value for operation><8 byte address of next list element>
        #     The end of the list is denoted by a 0 value for the next list element.
```

## Getting started

0. create a simple binary that just links one of the simple data files. Then use gdb to poke around the data area of memory so that you have a solid understanding of what the commands look like in memory
1. create a simple driver that iterates over the command array, don't worry about doing any processing yet
  - use gdb to ensure that it is doing what you expect
2. turn your `and`, `or` and `sum` routines from the last assignment into functions that your main program can link and
   call
3. create some test data files to test your progam.  See the examples in the data directory (specifically `simpleone_cmds.S` and `basic_cmds.S`)
4. once you think things are working, add support for writing the outputs as specified to standard out
  - to do this you will need to use the write system call
    - the easiest thing is to call write 4 times,
      1. to write out the final value of `rax`
      2. to write out the final value of `SUM_POSITIVE`
      3. to write out the final value of `SUM_NEGATIVE`
      4. to write the memory between `CALC_DATA_BEGIN` and `CALC_DATA_END`

5. the data directory contains the output from our reference implementation of the calculator for each example data file.
  - examples of the output can be found in the `reference*.resbin` files in the `data` directory
      - remember these are raw binary files so you will need to use appropriate tools to display their values in hex or other formats
        - `od -l -Ad` or `hexdump -C` or `xxd`
	- given the order for writing the outputs specified above, the first 24 bytes should be the three results computed
	  - the `head` command can come in very useful as you can use it to only read and output a restricted number of  `count` bytes.
	     - eg.  `head -c 24 reference_calc_simpleone.resbin` reads only the first 24 bytes of the file
	       - remember however these bytes are raw 8 byte values NOT ASCII
	         - you would need to pipe the output to another command to convert the values into an ASCII represetation of the
		   bytes in 'hex' or as 'long decimal'
     - later when working on the 'U' command, you might find the UNIX 'strings' command very useful.
   - To save the output from running your program to a file 
     - use bash redirection to direct the standard out of your program to a file (remember those first lectures)
   - find some unix commands that let you compare your output with the reference outputs so that you can see if you program
     is behaving correctly
   - the `testcalc.sh` can be very helpful see notes below
6. make sure your program exits correctly when it is done by calling the `exit` system call with a return code of 0.
7. work on adding more of the commands
  - start by adding 'U'
     - see `data/upperonly_cmds.S`, `data/easy_cmds.S` and  `data/basicwithupper_cmds.S`
  - then try adding 'a'
     - see `data/arraysum_cmds.S`
  - then try adding 'l'
     - see `data/listsum_cmds.S`
  - at this point you should be able to process  `simplerandom_cmds.S` and produce the matching binary output
  - bonus++: 'I', 'A' and 'L'
     - see `atoq_cmds.S`, `array_cmds.S` and `list_cmds.S`

### Helpful things

Various things have purposely been left vague so that you can explore how to use your UNIX and binary knowledge to figure things out.
So explore! Don't just ask for what command to use or how to do something.  Trying things and then ask detailed questions in the context of what you have tried.

- Use the debugger alot!
- be very careful about how you use your registers between you different functions.
  - come up with a plan to make sure that your calling code and your callee code don't trample over "live" values
  - know which registers are being used to pass values as arguments
  - know which registers are free to be used in a function to do work
  - you can always spill if you need too
- create your own  data files
- use the `./mkrandop` shell script to create data file of varying complexity.
   - We are still working on testing this script but it should be good enough to try
     - `data/mkrandop <count> [command types....]`
        - this will output to standardout a data .S file that has count instances of random commands from those listed as the addional arguments
	- if no args are given it will print a data file of 1 command from the basic set `&`, `|`, `S`

## Grading

- We will be testing your code with the example data files
- We will be reading over your code
- We will be inspecting your git histories.

Write good comments in all your files and make sure your git history documents your effort.

Ask detailed questions after exploring while you write and debug your code.  This assignment is all about growing your knowledge and skills as a binary wizard.  Don't cheat yourself out of this experience.

## `testcalc.sh` and the `prebin` and `resbin` files

To test your code we will be using the included script.  READ this script to understand how it works.  It is using gdb to create a binary file from the beginning state of your program -- `prebin`.  It then runs your program and redirects the standard output to `resbin` file (which of course will also be binary data)  It then uses `xdd` and `diff` to display what bytes have changed and what their values are.  If your program is behaving correctly, the changes will match what our reference program did.

In the data directory are the `prebin` and `resbin` files from the reference program for each data file.  If you pass an extra argument to the `testcalc.sh` script it will compare your program's changes to the reference program's changes.

The following is an example of using the `testcalc.sh` script.

```
$ ./testcalc.sh calc_simpleone
as -g and.S -o and.o
as -g or.S -o or.o
as -g sum.S -o sum.o
as -g upper.S -o upper.o
as -g arraysum.S -o arraysum.o
as -g listsum.S -o listsum.o
as -g array.S -o array.o
as -g list.S -o list.o
as -g atoq.S -o atoq.o
as -g calc.S -o calc.o
ld -g and.o or.o sum.o upper.o arraysum.o listsum.o array.o list.o atoq.o calc.o data/simpleone_cmds.o -o calc_simpleone
running gdb ... you will have to look in ./testcalc.sh to see what we are doing
running calc_simpleone saving standard output to calc_simpleone.resbin
The changes that calc_simpleone produced
1c1
< 00000000: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  ................
---
> 00000000: ef be ad de ef be ad de 00 00 00 00 00 00 00 00  ................
```

In the above we see that the first sixteen bytes have been changed.

If you want to see how your changes compare to what reference program does you can
look at the `data/reference_calc_simpleone.prebin` and `data/reference_calc_simpleone.resbin` files.

The `testcalc.sh` has support for comparing your changes to reference files if you pass it an extra argument `eg. ./testcalc.sh calc_simpleone 1`.

The following is an example of using the `./testcalc.sh` in this way.

```
$ ./testcalc.sh calc_simpleone 1
as -g and.S -o and.o
as -g or.S -o or.o
as -g sum.S -o sum.o
as -g upper.S -o upper.o
as -g arraysum.S -o arraysum.o
as -g listsum.S -o listsum.o
as -g array.S -o array.o
as -g list.S -o list.o
as -g atoq.S -o atoq.o
as -g calc.S -o calc.o
ld -g and.o or.o sum.o upper.o arraysum.o listsum.o array.o list.o atoq.o calc.o data/simpleone_cmds.o -o calc_simpleone
running gdb ... you will have to look in ./testcalc.sh to see what we are doing
running calc_simpleone saving standard output to calc_simpleone.resbin
The changes that calc_simpleone produced
1c1
< 00000000: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  ................
---
> 00000000: ef be ad de ef be ad de 00 00 00 00 00 00 00 00  ................
Good job your binary matches the behavior of the reference program
PASS
1/1
$
```

Start early and HAVE FUN!
